"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

from py4web import action, request, abort, redirect, URL
from yatl.helpers import A
from .common import db, session, T, cache, auth, logger, authenticated, unauthenticated, flash, Field
from py4web.utils.url_signer import URLSigner
from .models import get_user_email, get_uuid
from py4web.utils.form import Form, FormStyleBulma
from pydal.validators import *
import uuid
import random

#TODO: 需删除以下部分
EXAMPLE_USER = "qhuang24@ucsc.edu"

url_signer = URLSigner(session)

@action('index')
@action.uses(db, auth, 'index.html')
def index():
    print("User:", get_user_email())
    #加入本地的user database中
    if get_user_email() is not None:
        check_user=db(db.user.email == get_user_email()).select().first()
        if check_user == None:
            userInfo=db(db.auth_user.email == get_user_email()).select().first()
            db.user.insert(
                first_name=userInfo.first_name,
                last_name=userInfo.last_name,
                uuid=get_uuid(),
                email=userInfo.email
            )
    #TODO: 修改选择商品通过判断它的星星数量进行推荐
    return dict(
        searchBar_url = URL('searchBar', signer=url_signer),
        get_username_url = URL('get_username', signer=url_signer),
        get_products_url = URL('get_products', signer=url_signer),
    )

@action('get_username')
@action.uses(db, url_signer.verify())
def get_username():
    #TODO: 修改EXAMPLE_USER为get_user_email（）去主动获得当前用户信息
    if get_user_email() is not None:
        userInfo=db(db.user.email == get_user_email()).select().first()
        print(userInfo.id)
        userInfo_N=db(db.user_option_Info.user_id == userInfo.id).select().first()
        if userInfo_N != None:
            print("1")
            if userInfo_N.nickname != None:
                print("2")
                userName=userInfo_N.nickname
            else:
                userName=userInfo.first_name +" "+userInfo.last_name
        else:
            userName=userInfo.first_name +" "+userInfo.last_name
    else:
        userName = ""
    print("3")
    print(userName)
    return dict(userName=userName)

@action('get_products')
@action.uses(db, url_signer.verify())
def get_products():
    products=db(db.product).select().as_list()
    return dict(products=products)

@action('searchBar')
@action.uses()
def searchBar():
    """Gets the list of products, possibly in response to a query."""
    query = request.params.get('q')
    if query:
        no_space_query = query.strip()
        q = ((db.product.product_name.contains(no_space_query)) |
             (db.product.description.contains(no_space_query)))
    else:
        q = db.product.id > 0
    # This is a bit simplistic; normally you would return only some of
    # the products... and add pagination... this is up to you to fix.
    results = db(q).select(db.product.ALL).as_list()
    # Fixes some fields, to make it easy on the client side.
    for result in results:
        result['desired_quantity'] = min(1, result['quantity'])
        result['cart_quantity'] = 0
    return dict(
        results=results,
    )



#----------------------------------Layout Setting ------------------------------------
@action('registration', method=["GET", "POST"])
@action.uses(db, session, auth, 'registration.html')
def registration():
    id=db(db.user.email == get_user_email()).select().first().id
    print("id", id)
    form = Form(
        [Field('nickname'),
         Field('sex'),
         Field('day', 'integer', requires=IS_INT_IN_RANGE(1, 32)),
         Field('month', requires=IS_INT_IN_RANGE(1, 13)),
         Field('year', requires=IS_INT_IN_RANGE(1800, 1e6)),
         Field('age', requires=IS_INT_IN_RANGE(0, 150)),
         Field('zipcode')], 
        csrf_session=session,
        formstyle=FormStyleBulma)
    if form.accepted:
        check=db(db.user_option_Info.user_id == id).select().first()
        if check == None:
            db.user_option_Info.insert(
                user_id=id,                        ########################TODO: FOREIGN KEY constraint failed#############
                nickname=form.vars['nickname'],
                sex=form.vars['sex'],
                day=form.vars['day'],
                month=form.vars['month'],
                year=form.vars['year'],
                age=form.vars['age'],
                zipcode=form.vars['zipcode']
            )
        else: 
            db(db.user_option_Info.user_id == id).update(
                nickname=form.vars['nickname'],
                sex=form.vars['sex'],
                day=form.vars['day'],
                month=form.vars['month'],
                year=form.vars['year'],
                age=form.vars['age'],
                zipcode=form.vars['zipcode']
            )
        redirect(URL('index'))
    return dict(form=form)
#======================================================================================


#--------------------------Layout user_profile----------------------------------------
@action('user_profile')
@action.uses(db, auth.user, 'user_profile.html')
def user_profile():
    print("User:", get_user_email())
    form = Form(db.user_rate_it, csrf_session=session, formstyle=FormStyleBulma)
    return dict(
        upload_user_image_url = URL('upload_user_image', signer=url_signer),
        load_Info_url = URL('load_Info', signer=url_signer),
        show_items_url = URL('show_items', signer=url_signer),
        #TODO: 未完成，在community部分写完后取消注释
        #show_community_status_url = URL('show_community_status', signer=url_signer),
        form=form
    )

#TODO: 未完成，在community部分写完后取消注释 并且将这行代码复制到user_profile.html中去“let show_community_status_url = "[[=XML(show_community_status_url)]]";”
# @action('show_community_status')
# @action.uses(db, auth, url_signer.verify())
# def show_community_status():
#     id = request.params.get("user_id")
#     posts = db(db.post.user_id == id).select().as_list()
#     return dict(posts=posts)

@action('show_items')
@action.uses(db, auth, url_signer.verify())
def show_items():
    id = request.params.get("user_id")
    products = db(db.product.user_id == id).select().as_list()
    return dict(products=products) 

@action('load_Info')
@action.uses(db, auth.user, url_signer.verify())
def load_Info():
    user = db(db.user.email == get_user_email()).select().as_list()
    user_id = user[0]['id']
    user_Info = db(db.user_option_Info.user_id == user_id).select().as_list()
    print(user_Info)
    if len(user_Info) > 0: 
        user[0].update(user_Info[0])
    else:
        user[0].update({'user_description': "Sorry, I do not write anything right now ^_^!"})
    return dict(user=user[0])


@action('upload_user_image', method= "POST")
@action.uses(db, auth.user, url_signer.verify())
def upload_user_image():
    id = db(db.user.email == get_user_email()).select().first().id
    image = request.json.get("image")
    print(image)
    check = db(db.user_option_Info.user_id == id).select().first()
    if check is None:
        db.user_option_Info.insert(
            user_id = id,
            user_image = image,
        )
    else:    
        db(db.user_option_Info.user_id == id).update(
            user_image = image
        )
    return "ok"
#==============================================================================
# #------------------------------

# @action("community")
# @action.uses(db, auth, url_signer, "community.html")
# def index():
#     return dict(
#         load_url=URL("load_post", signer=url_signer),
#         add_url=URL("add_post", signer=url_signer),
#         load_voters_url=URL("load_voters", signer=url_signer),
#         vote_url=URL("vote", signer=url_signer),
#         delete_url=URL("delete", signer=url_signer),
#         auth_url=URL("auth/login", signer=url_signer),
#         first_name=auth.current_user.get("first_name"),
#         last_name=auth.current_user.get("last_name"),
#         user_id=auth.current_user.get("id"),
#         authenticated=auth.current_user.get("id") is not None,
#     )

# @action("load_post")
# @action.uses(url_signer.verify(), db)
# def load_post():
#     user_id = (
#         auth.current_user.get("id") if auth.current_user.get("id") is not None else -1
#     )
#     posts = db(db.post).select(orderby=~db.post.id).as_list()
#     votes = db(db.vote.user == user_id).select().as_list()
#     return dict(posts=posts, votes=votes)


# @action("add_post", method="POST")
# @action.uses(url_signer.verify(), db)
# def add_post():
#     user_name = (
#         auth.current_user.get("first_name") + " " + auth.current_user.get("last_name")
#     )
#     id = db.post.insert(
#         user=auth.current_user.get("id"),
#         user_name=user_name,
#         text=request.json.get("text"),
#     )
#     return dict(id=id)


# @action("load_voters")
# @action.uses(url_signer.verify(), db)
# def load_voters():
#     post = request.params.get("id")
#     valence = request.params.get("valence") == "true"

#     voters = (
#         db(
#             (db.auth_user.id == db.vote.user)
#             & (db.vote.valence == valence)
#             & (db.vote.post == post)
#         )
#         .select(db.auth_user.first_name, db.auth_user.last_name)
#         .as_list()
#     )
#     return dict(voters=voters)


# @action("vote")
# @action.uses(url_signer.verify(), db)
# def vote():
#     valence = request.params.get("valence") == "true"
#     post = request.params.get("id")
#     user = auth.current_user.get("id")

#     selected_vote_set = db((db.vote.user == user) & (db.vote.post == post))

#     if selected_vote_set.isempty():
#         id = db.vote.insert(post=post, user=user, valence=valence)
#     else:
#         selected_vote = selected_vote_set.select()[0]
#         id = selected_vote.id
#         if selected_vote.valence == valence:
#             db(db.vote.id == id).delete()
#         else:
#             db(db.vote.id == id).update(valence=valence)
#     # print(db().select(db.vote.ALL))
#     return dict(id=id)


# @action("delete")
# @action.uses(url_signer.verify(), db)
# def delete():
#     post = request.params.get("id")
#     db(db.post.id == post).delete()
#     return dict(id=post)





# #------------------------------








#--------------------------------------manage_products------------------------------------------
 
@action('manage_products')
@action.uses(db, auth.user, url_signer, 'manage_products.html')
def manage_products():
    return dict(
        # This is the signed URL for the callback.
        load_url = URL('load_products', signer=url_signer),
        add_url = URL('add_product', signer=url_signer),
        delete_url = URL('delete_product', signer=url_signer),
        edit_url = URL('edit_product', signer=url_signer),
        upload_url = URL('upload_image', signer=url_signer),
    )

# This is our very first API function.
@action('load_products')
@action.uses(auth.user, url_signer.verify(), db)
def load_products():
    id = db(db.user.email == get_user_email()).select().first().id
    rows = db(db.product.user_id == id).select().as_list()
    return dict(rows=rows)

@action('add_product', method="POST")
@action.uses(auth, url_signer.verify(), db)
def add_product():
    user_id=db(db.user.email == get_user_email()).select().first().id
    description=request.json.get('description')
    if description == "":
        description="Sorry, the owner do not add any description!"
    id = db.product.insert(
        user_id=user_id,
        product_name=request.json.get('product_name'),
        quantity=request.json.get('quantity'),
        price=request.json.get('price'),
        description=description,
    )
    return dict(id=id)

@action('delete_product')
@action.uses(auth, url_signer.verify(), db)
def delete_product():
    id = request.params.get('id')
    assert id is not None
    db(db.product.id == id).delete()
    return "ok"

@action('edit_product', method="POST")
@action.uses(auth, url_signer.verify(), db)
def edit_product():
    id = request.json.get("id")
    field = request.json.get("field")
    value = request.json.get("value")
    db(db.product.id == id).update(**{field: value})
    return "ok"

@action('upload_image', method="POST")
@action.uses(auth, url_signer.verify(), db)
def upload_image():
    product_id = request.json.get("product_id")
    image = request.json.get("image")
    db(db.product.id == product_id).update(image=image)
    return "ok"

#==================================================================================