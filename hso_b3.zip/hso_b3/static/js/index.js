// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        // Complete as you see fit.
        add_mode: false,
        page_mode: true,
        rater_up_status: false,
        rater_down_status: false,
        check: false,
        liked_user_name: [],
        disliked_user_name: [],
        post_content: "",
        rows: [],
    };

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;
    };

    app.add_post = function() {
        axios.post(add_contact_url, 
            {
                post_content: app.vue.post_content,
            }).then(function (response){
                app.vue.rows.push({
                    id: response.data.id,
                    first_name: response.data.first_name,
                    last_name: response.data.last_name,
                    post_content: app.vue.post_content,
                });
                app.enumerate(app.vue.rows);
                app.reset_form(false);
                app.set_add_status(false);
                app.init();
            })
    };

    app.reset_form = function() {
        app.vue.post_content = "";
    };

    app.set_add_status = function(new_status) {
        app.vue.add_mode = new_status;
        app.vue.page_mode = !new_status; 
    };

    app.complete = (rows) => {
        rows.map((row) => {
            row.up_rating_status=false;
            row.down_rating_status=false;

            row.up_rating_status_display=false;
            row.down_rating_status_display=false;

            row.rater_status=false;

            row.show_delete=false;
        })
    };

    app.delete_post = function(row_idx) {
        let id = app.vue.rows[row_idx].id;
        axios.get(delete_contact_url, {params: {id: id}}).then(function(response) {
            for(let i = app.vue.rows.length-1; i >= 0; i--) {
                if(app.vue.rows[i].id === id) {
                    app.vue.rows.splice(i, 1);
                    app.enumerate(app.vue.rows);
                    break;
                }
            }
        });
    };

    app.set_user_check = function(row_idx) {
        let row = app.vue.rows[row_idx];
        axios.get(get_username_url, {params: {post_id: row.id}}).then(function(response) {
            row.liked_user_name = response.data.liked_user_Name;
            row.disliked_user_name = response.data.disliked_user_Name;
        });
    };

    app.mouse_up_in = function(row_idx) {
        let row = app.vue.rows[row_idx];
        row.rater_status_up=true;
        app.vue.rater_up_status = row.rater_status_up;
    };

    app.mouse_up_out = function(row_idx) {
        let row = app.vue.rows[row_idx];
        row.rater_status_up=false;
        app.vue.rater_up_status = row.rater_status_up;
    };

    app.mouse_down_in = function(row_idx) {
        let row = app.vue.rows[row_idx];
        row.rater_status_down=true;
        app.vue.rater_down_status = row.rater_status_down;
    };

    app.mouse_down_out = function(row_idx) {
        let row = app.vue.rows[row_idx];
        row.rater_status_down=false;
        app.vue.rater_down_status = row.rater_status_down;
    };

    app.set_up_rating_status = function(row_idx, up_rating_status) {
        let row = app.vue.rows[row_idx];
        row.up_rating_status = !up_rating_status;
        row.up_rating_status_display = row.up_rating_status;
        if( row.down_rating_status == true && row.down_rating_status_display == true) {
            row.down_rating_status = false;
            row.down_rating_status_display = false;
        }
        axios.post(set_rating_url,
        {
            post_id: row.id,
            rating_up: row.up_rating_status,
            rating_down: row.down_rating_status,
        }).then((response) => {
            row.liked_user_name = response.data.liked_user_Name;
            row.disliked_user_name = response.data.disliked_user_Name;
        })
    };

    app.set_down_rating_status = function(row_idx, down_rating_status) {
        let row = app.vue.rows[row_idx];
        row.down_rating_status = !down_rating_status;
        row.down_rating_status_display = row.down_rating_status;
        if( row.up_rating_status == true && row.up_rating_status_display == true) {
            row.up_rating_status = false;
            row.up_rating_status_display = false;
        }
        axios.post(set_rating_url,
        {
            post_id: row.id,
            rating_up: row.up_rating_status,
            rating_down: row.down_rating_status,
        }).then((response) => {
            row.liked_user_name = response.data.liked_user_Name;
            row.disliked_user_name = response.data.disliked_user_Name;
        })
    };

    // This contains all the methods.
    app.methods = {
        // Complete as you see fit.
        add_post: app.add_post,
        set_add_status: app.set_add_status,
        complete: app.complete,
        delete_post: app.delete_post,
        set_user_check: app.set_user_check,
        mouse_down_in: app.mouse_down_in,
        mouse_down_out: app.mouse_down_out,
        mouse_up_in: app.mouse_up_in,
        mouse_up_out: app.mouse_up_out,
        set_up_rating_status: app.set_up_rating_status,
        set_down_rating_status: app.set_down_rating_status,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        // Typically this is a server GET call to load the data.
        axios.get(load_contacts_url).then(function (response) {
            app.vue.rows = app.enumerate(response.data.rows);
            app.vue.user_name = response.data.user_name;
            app.vue.complete(response.data.rows);
            for(let i = response.data.rows.length-1; i >= 0; i--) {
                if(response.data.current_user == response.data.rows[i].user_Email){
                    app.vue.check=true;
                    app.vue.rows[i].show_delete = true;
                } else {
                    app.vue.rows[i].show_delete = false;
                }
            }
            for(let i = response.data.rows.length-1; i>=0; i--){
                app.vue.set_user_check(i);
            }
        }).then(() => {
            for (let row of app.vue.rows) {
                axios.get(get_rating_url, {params: {"row_id": row.id}})
                .then((result) => {
                    row.up_rating_status=result.data.rating_up;
                    row.down_rating_status=result.data.rating_down;
                    row.up_rating_status_display=row.up_rating_status;
                    row.down_rating_status_display=row.down_rating_status;
                    app.vue.$forceUpdate();
                });
            }
        });
        axios.get()
    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code i
init(app);
