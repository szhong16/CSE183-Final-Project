"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

from py4web import action, request, abort, redirect, URL
from yatl.helpers import A
from .common import db, session, T, cache, auth, logger, authenticated, unauthenticated, flash
from py4web.utils.url_signer import URLSigner
from .models import get_user_email
from py4web.utils.form import Form, FormStyleBulma


url_signer = URLSigner(session)

@action('index')
@action.uses(db, auth, 'index.html')
def index():
    print("User:", get_user_email())
    return dict()

@action('user_settings', method=["GET", "POST"])
@action.uses(db, session, auth, 'user_settings.html')
def registration():
    form = Form(db.user_option_Info, csrf_session=session, formstyle=FormStyleBulma)
    if form.accepted:
        redirect(URL('index'))
    return dict(form=form)

@action('user_profile')
@action.uses(db, auth, 'user_profile.html')
def user_profile():
    print("User:", get_user_email())
    form = Form(db.user_rate_it, csrf_session=session, formstyle=FormStyleBulma)
    return dict(
        add_contact_url = URL('add_contact', signer=url_signer),
        delete_contact_url = URL('delete_contact', signer=url_signer),
        form=form
    )

@action('add_contact', method="POST")
@action.uses(auth.user, url_signer.verify(), db)
def add_contact():
    name = db(db.auth_user.email == get_user_email()).select().first()
    id = db.contact.insert(
        first_Name=name.first_name,
        last_Name=name.last_name,
        post_content=request.json.get('post_content'),
    )
    return dict(id=id, first_name=name.first_name, last_name=name.last_name)

@action('delete_contact')
@action.uses(auth.user, url_signer.verify(), db)
def delete_contact():
    id = request.params.get('id')
    user=db(db.auth_user.email == get_user_email()).select().first()

    db(
        (db.contact.id == id) &
        (db.contact.first_Name == user.first_name) &
        (db.contact.last_Name == user.last_name)
    ).delete()
    return "GG"

@action('item_info')
@action.uses(db, auth, 'item_info.html')
def item_info():
    item_name = "1986 Toyota Corolla"
    item_desc = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lectus mi, varius vel fringilla eleifend, porta sed ante. Donec dui tortor, dignissim vel fringilla sed, lobortis a felis. Ut sit amet consectetur lacus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Mauris porta imperdiet velit euismod facilisis. Morbi at scelerisque sem. Maecenas mi lectus, pharetra vel leo posuere, venenatis pulvinar ligula. Vestibulum feugiat arcu urna, quis facilisis augue aliquet et."
    post_time = "<the distant future>"
    post_owner = "<owner>"

    return dict(
        item_name=item_name,
        item_desc=item_desc,
        post_creat_time=post_time,
        post_owner=post_owner
    )