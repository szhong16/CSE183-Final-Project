"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

from py4web import action, request, abort, redirect, URL
from yatl.helpers import A
from .common import db, session, T, cache, auth, logger, authenticated, unauthenticated, flash
from py4web.utils.url_signer import URLSigner
from .models import get_user_email, get_user

url_signer = URLSigner(session)

@action('index')
@action.uses(db, auth, 'index.html')
def index():
    return dict(
        # COMPLETE: return here any signed URLs you need.
        load_contacts_url = URL('load_contacts', signer=url_signer),
        add_contact_url = URL('add_contact', signer=url_signer),
        delete_contact_url = URL('delete_contact', signer=url_signer),
        get_post_url = URL('get_post', signer=url_signer),
        get_rating_url = URL('get_rating', signer=url_signer),
        set_rating_url = URL('set_rating', signer=url_signer),
        get_username_url =URL('get_username', signer=url_signer),
    )

@action('load_contacts')
@action.uses(url_signer.verify(), db)
def load_contacts():
    rows = db(db.contact).select().as_list() 
    return dict(rows=rows)

@action('add_contact', method="POST")
@action.uses(auth.user, url_signer.verify(), db)
def add_contact():
    name = db(db.auth_user.email == get_user_email()).select().first()
    id = db.contact.insert(
        first_Name=name.first_name,
        last_Name=name.last_name,
        post_content=request.json.get('post_content'),
    )
    return dict(id=id, first_name=name.first_name, last_name=name.last_name)

@action('delete_contact')
@action.uses(auth.user, url_signer.verify(), db)
def delete_contact():
    id = request.params.get('id')
    user=db(db.auth_user.email == get_user_email()).select().first()
    
    db(
        (db.contact.id == id) &
        (db.contact.first_Name == user.first_name) &
        (db.contact.last_Name == user.last_name)
    ).delete()
    return "GG"

@action('get_username')
@action.uses(url_signer.verify(), db)
def get_username():
    id = request.params.get('id')
    post_user= db(db.contact.id == id).select().first()
    if post_user.user_Email == get_user_email():
        delete_show = True
    else:
        delete_show = False
    return dict(delete_show=delete_show)

@action('get_rating')
@action.uses(url_signer.verify(), db, auth.user)
def get_rating():
    """Returns the rating for a user and an image."""
    id = request.params.get('row_id')
    row = db((db.thumbs.post_id == id) &
             (db.thumbs.rater == get_user())).select().first()
    rating_up = row.rating_up if row is not None else False
    rating_down = row.rating_down if row is not None else False
    return dict(rating_up=rating_up, rating_down=rating_down)


@action('set_rating', method='POST')
@action.uses(auth.user, url_signer.verify(), db)
def set_rating():
    """Sets the rating for an image."""
    id = request.json.get('post_id')
    rating_up = request.json.get('rating_up')
    rating_down = request.json.get('rating_down')
    assert id is not None and rating_up is not None and rating_down is not None
    db.thumbs.update_or_insert(
        ((db.thumbs.post_id == id) & (db.thumbs.rater == get_user())),
        post_id=id,
        rating_up=rating_up,
        rating_down=rating_down,
        rater=get_user(),
    )
    return "ok"