let app = {};

let init = (app) => {
    app.data = {
        fields: [
            ['Type Your Message Here','msg']
        ],
        add_fields: {},
        add_mode: false,
        rows: [],
    };


    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;
    };

    // This decorates the rows (e.g. that come from the server)
    // adding information on their state:
    // - clean: read-only, the value is saved on the server
    // - edit : the value is being edited
    // - pending : a save is pending.
    app.decorate = (a) => {
        for (e of a) {
            e._state = {}
            for (f of app.vue.fields) {
                e._state[f[1]] = "clean";
            }
        }
        return a;
    }


    app.send = function () {
        app.reset_form();
    };

    app.methods = {
        // create: app.create
        // delete: app.delete
        send: app.send
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    app.init = () => {
        for (let f of app.vue.fields) {
            app.vue.add_fields[f[1]] = "";
        }
        axios.get(load_url).then(function (response) {
            app.vue.rows = app.decorate(app.enumerate(response.data.rows));
        });
    };

    app.init();
};

init(app);
