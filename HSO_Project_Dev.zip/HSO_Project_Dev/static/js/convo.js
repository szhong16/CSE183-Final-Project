// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};


// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {

    // This is the Vue data.
    app.data = {
        login_status: "out",
        user: "",
        user_id: "",
        msg_content: "",
        msgs: [],
    };

    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;
    };

    app.set_add_status = function (new_status) {
        app.vue.add_status = new_status;
        app.vue.msg_content = "";
    }

    app.add_msg = function () {
        axios.msg(add_msg_url, {
            msg_content: app.vue.msg_content,
        }).then(function (response) {
            //TODO: 判断image是否为空，空着加入默认头像，否则加入msg_user头像
            if (response.data.msg[0].msg_user_image === "") {
                temp_image = "";    //TODO: 还未加入默认头像，！！！！！！！！！！！！！！！！！！！！！！！！！！！
            } else {
                temp_image = response.data.msg[0].msg_user_image
            }
            app.vue.msgs.push({
                msg_id: response.data.msg[0].id,
                user_id: response.data.msg[0].user_id,
                msg_content: app.vue.msg_content,
                msg_username: response.data.msg[0].msg_username,
                msg_user_image: temp_image,
            });
            app.enumerate(app.vue.msgs);
            app.vue.msg_content = "";
            app.vue.add_status = false;
            app.init( );
        });
    }

    app.delete_msg = function(row_idx) {
        let id = app.vue.msgs[row_idx].id;
        axios.get(delete_msg_url, {params: {id: id}}).then(function(response) {
            for(let i = app.vue.msgs.length-1; i >= 0; i--) {
                if(app.vue.msgs[i].id === id) {
                    app.vue.msgs.splice(i, 1);
                    app.enumerate(app.vue.msgs);
                    break;
                }
            }
        });
    };

    app.complete = (rows) => {
        rows.map((row) => {
            row.up_rating_status=false;
            row.down_rating_status=false;

            row.up_rating_status_display=false;
            row.down_rating_status_display=false;
        })
    };

    // This contains all the methods.
    app.methods = {
        add_msg: app.add_msg,
        delete_msg: app.delete_msg,
        complete: app.complete,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        axios.get(load_chat_url)
            .then(function (response) {
                if (response.data.user.length < 1) {
                    app.vue.login_status = "out";
                } else {
                    app.vue.login_status = "in";
                }
                app.complete(response.data.msgs);
                app.vue.user = response.data.user;
                app.vue.user_id = response.data.user_id;
                app.vue.msgs = response.data.msgs;
                app.enumerate(app.vue.msgs);
                //如果当前用户登录则进入，否则不进入。 进入后检查用户的头像是否为空，如果不为空寻找相应帖子并且更新头像。
                if(app.vue.user.length > 0) {
                    if (app.vue.user[0].user_image != null) {
                        for(let i = 0; i < app.vue.msgs.length; i++){
                            if (app.vue.msgs[i].user_id === app.vue.user_id) {
                                app.vue.msgs[i].msg_user_image = app.vue.user[0].user_image;
                                axios.msg(update_image_url,{
                                    id: app.vue.msgs[i].id,
                                    image: app.vue.msgs[i].msg_user_image
                                }).then();
                            }
                        }
                    }
                }
            }).then(() => {
                for (let row of app.vue.msgs) {
                    axios.get(get_rating_url, {params: {"row_id": row.id}})
                    .then((result) => {
                        /*row.up_rating_status=result.data.rating_up;
                        row.down_rating_status=result.data.rating_down;
                        row.up_rating_status_display=row.up_rating_status;
                        row.down_rating_status_display=row.down_rating_status;*/
                        app.vue.$forceUpdate();
                    });
                }
            });
    };

    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code i
init(app);
