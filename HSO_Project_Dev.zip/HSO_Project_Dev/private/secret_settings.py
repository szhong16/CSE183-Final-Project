# single sign on Google (will be used if provided)
OAUTH2GOOGLE_CLIENT_ID = '271260584229-icb18jc3o0n4jh7dpqqv4skf7e0ljjs4.apps.googleusercontent.com'
OAUTH2GOOGLE_CLIENT_SECRET = 'fCS1Sfz_GIfHchzIhVmZv7Eh'

DB_USER = 'hso_user'
DB_NAME = 'hsodb'
DB_PASSWORD = 'password'
DB_CONNECTION = 'lunar-hangar-276507:us-west4:hso-db'
